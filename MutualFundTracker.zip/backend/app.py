
from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# Initialize database
conn = sqlite3.connect('mutual_funds.db', check_same_thread=False)
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS investments (
    id INTEGER PRIMARY KEY,
    fund_name TEXT,
    amount REAL
)
""")
conn.commit()

@app.route('/add', methods=['POST'])
def add_investment():
    data = request.json
    cursor.execute("INSERT INTO investments (fund_name, amount) VALUES (?, ?)", 
                   (data['fund_name'], data['amount']))
    conn.commit()
    return jsonify({'message': 'Investment added successfully'})

@app.route('/get_investments', methods=['GET'])
def get_investments():
    cursor.execute("SELECT * FROM investments")
    investments = cursor.fetchall()
    return jsonify(investments)

if __name__ == '__main__':
    app.run(debug=True)
